# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 11:46:19 2019

@author: asp5423
"""



from PyQt5.QtWidgets import QPushButton



class SiloBase(object):

    def __init__(self, name, height):
        super(SiloBase, self).__init__()

        self.name = name;
        self.height = height;

        self.point_count = None
        self.point_pos = None
        self.isDraw = None
        self.repose_angle = None
        self.percent_error = None


    def setName(self, name):
        self.name = name
    def getName(self):
        return self.name

    def setHeight(self, height):
        self.height = height
    def getHeight(self):
        return self.height

    def set_point_count(self, point_count):
        self.point_count = point_count

    def get_point_count(self):
        return self.point_count

    def set_point_pos(self, point_pos):
        self.point_pos = point_pos

    def get_point_pos(self):
        return self.point_pos

    def set_isDraw(self, isDraw):
        self.isDraw = isDraw

    def get_isDraw(self):
        return self.isDraw

    def set_repose_angle(self, repose_angle):
        self.repose_angle = repose_angle

    def get_repose_angle(self):
        return self.repose_angle

    def set_percent_error(self, percent_error):
        self.percent_error = percent_error

    def get_percent_error(self):
        return percent_error

class SiloSquare(object):
    def __init__(self, name, height, side_len):
        super(SiloSquare, self).__init__()

        self.side_len = side_len;
        self.silo = SiloBase(name, height)

    def getSilo(self):
        return self.silo

    def setSideLen(self, side_len):
        self.side_len = side_len
    def getSideLen(self):
        return self.side_len


class SiloCircle(object):
    def __init__(self, name, height, radius):
        super(SiloCircle, self).__init__()

        self.radius = radius;
        self.silo = SiloBase(name, height)

    def getSilo(self):
        return self.silo

    def setRadius(self, radius):
        self.radius = radius
    def getRadius(self):
        return self.radius


class SiloView(object):
    WIDTH = 150
    HEIGHT = 150
    def __init__(self, silo, window):
        super(SiloView, self).__init__()
        self.window = window
        self.siloViewManager = window.sm
        if( isinstance(silo, SiloCircle) ):

            self.qt_button = QPushButton("Silo: %s\nheight: %d\nside length: %d"%(
                                            silo.getSilo().getName(),
                                            silo.getSilo().getHeight(),
                                            silo.getRadius()
                                        ), window)
        else:
            self.qt_button = QPushButton("Silo: %s\nheight: %d\nradius: %d"%(
                                            silo.getSilo().getName(),
                                            silo.getSilo().getHeight(),
                                            silo.getSideLen()
                                        ), window)


        self.qt_button.resize(SiloView.WIDTH, SiloView.HEIGHT)
        self.qt_button.show();


    def updateModel(self, silo):
        self.qt_button.setText("Silo: %s\nheight: %d\nside length: %d"%(
                                  silo.getSilo().getName(),
                                  silo.getSilo().getHeight(),
                                  silo.getSideLen()
                                 ))

        self.qt_button.show()

    def updatePos(self,x,y):
        self.qt_button.move(x,y)
        self.qt_button.show()
        self.qt_button.clicked.connect(self.click)
    def setIndex(self,index):
        self.index = index
    def getIndex(self):
        return self.index
    def click(self):
        if (self.window.removeMod == 1):
            self.siloViewManager.removeSilo(self.index)
            self.qt_button.deleteLater()
            self.window.excelIO.delete(self.index)
        else:
            pass
        pass

class SiloViewManager(object):
    ROWS = 3
    COLS = 5
    SPACING = 30
    def __init__(self):
        super(SiloViewManager, self).__init__()
        self.silo_list = []

    def addSilo(self, silo):
        if(silo is None or not isinstance(silo, SiloView)):
            raise("Must be of SiloSquareView type")
        if(len(self.silo_list) == SiloViewManager.ROWS * SiloViewManager.COLS):
            raise("Cannot fit additional silos into grid")

        self.silo_list.append(silo);

        silo_index = len(self.silo_list) - 1
        silo.setIndex(silo_index)

        col_index = silo_index%SiloViewManager.COLS
        row_index = silo_index//SiloViewManager.COLS

        x_pos = (col_index+1)*SiloViewManager.SPACING + col_index*SiloView.WIDTH
        y_pos = (row_index+1)*SiloViewManager.SPACING + row_index*SiloView.HEIGHT



        silo.updatePos(x_pos, y_pos)

    def removeSilo(self, index):
        for i in range(index+1, len(self.silo_list)):
            col_index = (i-1)%SiloViewManager.COLS
            row_index = (i-1)//SiloViewManager.COLS

            x_pos = (col_index+1)*SiloViewManager.SPACING + col_index*SiloView.WIDTH
            y_pos = (row_index+1)*SiloViewManager.SPACING + row_index*SiloView.HEIGHT

            self.silo_list[i].setIndex(i-1)
            self.silo_list[i].updatePos(x_pos, y_pos)
            self.silo_list[i-1] = self.silo_list[i]

        self.silo_list.pop(len(self.silo_list)-1)




