# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 11:45:46 2019

@author: asp5423
"""

import sys
from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets import QWidget
from PyQt5.QtWidgets import QPushButton
from PyQt5.QtWidgets import QDesktopWidget
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtWidgets import QMainWindow
from PyQt5.QtWidgets import QAction
from PyQt5.QtWidgets import qApp
from PyQt5.QtWidgets import QMenu
from PyQt5.QtWidgets import QLabel
from PyQt5.QtWidgets import QLineEdit

from PyQt5.QtCore import QCoreApplication, Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import pyqtSlot

import Silo
import Input
import Site
import SiloView
import excelio

class Main(QMainWindow):

    def __init__(self):

        super(Main, self).__init__()
        self.sm = Silo.SiloViewManager()
        self.removeMod =0
        self.setupWindow()

        self.setGeometry(90, 90, 1200, 800)
        self.setWindowTitle('site screen')

        menubar = self.menuBar()
        fileMenu = menubar.addMenu('File')
        siteMenu = menubar.addMenu('Site')

        impMenu = QMenu('remove a silo', self)
        impAct = QAction('which silo you want to remove', self)
        impMenu.addAction(impAct)
        impAct.triggered.connect(self.remove_Mod)


        imp2Menu = QMenu('remove a site', self)
        imp2Act = QAction('which site you want to remove', self)
        imp2Menu.addAction(imp2Act)

        self.newAct = QAction('add a silo', self)
        self.newSite = QAction('add a site', self)

        fileMenu.addAction(self.newAct)
        fileMenu.addMenu(impMenu)


        siteMenu.addAction(self.newSite)
        siteMenu.addMenu(imp2Menu)


        self.inView = None

        self.newAct.triggered.connect(self.createInputView)

        self.x = Silo.SiloSquare("apples", 12, 1)


        self.show()

        self.excelIO = excelio.Excel_Io(self)                    #import data in excel




        #self.silo_view = SiloView.createInputView(self, self.x)




    def setupWindow(self):
        frameGeo = self.frameGeometry()
        geoCenter = QDesktopWidget().availableGeometry().center()
        frameGeo.moveCenter(geoCenter)
        self.move(frameGeo.topLeft())

    def createInputView(self):
        self.inView = Input.createInputView(self);
        self.silo_view = SiloView.createInputView(self, self.x)

    def remove_Mod(self):
        self.removeMod ^= 1
        if self.removeMod == 1:
            self.setCursor(Qt.ClosedHandCursor)
        if self.removeMod == 0:
            self.setCursor(Qt.ArrowCursor)



app = QApplication(sys.argv)
main = Main()
sys.exit(app.exec_())